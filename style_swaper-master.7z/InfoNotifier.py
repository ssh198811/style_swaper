
class InfoNotifier:
    g_loss_info = ""
    g_progress_info = []
    style_preview_pic_dir=[]
    style_preview_pic_dir2=[]
    style_preview_pic_dir3=[]



